using ECommerceMarketplace.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// ======================================================
// DATABASE
// ======================================================

builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"));
});


// ======================================================
// IDENTITY
// ======================================================

builder.Services
    .AddIdentity<ApplicationUser, IdentityRole>(options =>
    {
        // User settings
        options.User.RequireUniqueEmail = true;

        // Password settings
        options.Password.RequiredLength = 6;
        options.Password.RequireDigit = true;
        options.Password.RequireLowercase = true;
        options.Password.RequireUppercase = false;
        options.Password.RequireNonAlphanumeric = true;
    })
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();


// ======================================================
// MVC
// ======================================================

builder.Services.AddControllersWithViews();


// ======================================================
// BUILD APP
// ======================================================

var app = builder.Build();


// ======================================================
// HTTP PIPELINE
// ======================================================

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();

app.UseAuthorization();


// ======================================================
// SEED ROLES + ADMIN
// ======================================================

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;

    try
    {
        await SeedRolesAndAdminAsync(services);
    }
    catch (Exception ex)
    {
        var logger = services
            .GetRequiredService<ILogger<Program>>();

        logger.LogError(
            ex,
            "An error occurred while creating Roles or Admin account.");
    }
}


// ======================================================
// ROUTE
// ======================================================

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");


// ======================================================
// RUN
// ======================================================

app.Run();


// ======================================================
// SEED ROLES + ADMIN METHOD
// ======================================================

static async Task SeedRolesAndAdminAsync(IServiceProvider services)
{
    var userManager =
        services.GetRequiredService<UserManager<ApplicationUser>>();

    var roleManager =
        services.GetRequiredService<RoleManager<IdentityRole>>();


    // ==================================================
    // CREATE REQUIRED ROLES
    // ==================================================

    string[] roles =
    {
        "Admin",
        "Customer",
        "Seller"
    };

    foreach (var role in roles)
    {
        if (!await roleManager.RoleExistsAsync(role))
        {
            var roleResult =
                await roleManager.CreateAsync(
                    new IdentityRole(role));

            if (!roleResult.Succeeded)
            {
                var errors = string.Join(
                    ", ",
                    roleResult.Errors.Select(e => e.Description));

                throw new Exception(
                    $"Could not create role '{role}': {errors}");
            }
        }
    }


    // ==================================================
    // ADMIN INFORMATION
    // ==================================================

    string adminEmail = "admin@ecommerce.com";
    string adminPassword = "Admin@12345";
    string adminUserName = "admin";


    // ==================================================
    // FIND ADMIN
    // ==================================================

    var admin = await userManager.FindByEmailAsync(
        adminEmail);


    // ==================================================
    // CREATE ADMIN IF DOESN'T EXIST
    // ==================================================

    if (admin == null)
    {
        admin = new ApplicationUser
        {
            UserName = adminUserName,
            Email = adminEmail,

            EmailConfirmed = true,

            IsActive = true,

            IsSeller = false,

            SellerRequestPending = false
        };


        var result = await userManager.CreateAsync(
            admin,
            adminPassword);


        if (!result.Succeeded)
        {
            var errors = string.Join(
                ", ",
                result.Errors.Select(e => e.Description));

            throw new Exception(
                "Could not create Admin: " + errors);
        }
    }
    else
    {
        // ==================================================
        // REACTIVATE ADMIN IF SUSPENDED
        // ==================================================

        admin.IsActive = true;

        admin.EmailConfirmed = true;

        admin.UserName = adminUserName;

        await userManager.UpdateAsync(admin);
    }


    // ==================================================
    // MAKE SURE ADMIN HAS ADMIN ROLE
    // ==================================================

    if (!await userManager.IsInRoleAsync(admin, "Admin"))
    {
        var roleResult =
            await userManager.AddToRoleAsync(
                admin,
                "Admin");

        if (!roleResult.Succeeded)
        {
            var errors = string.Join(
                ", ",
                roleResult.Errors.Select(e => e.Description));

            throw new Exception(
                "Could not add Admin role: " + errors);
        }
    }
}