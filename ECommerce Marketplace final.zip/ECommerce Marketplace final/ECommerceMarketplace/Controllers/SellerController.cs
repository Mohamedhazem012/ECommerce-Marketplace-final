﻿using ECommerceMarketplace.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommerceMarketplace.Controllers
{
    public class SellerController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public SellerController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // ======================================================
        // SELLER DASHBOARD
        // Products, Orders, Sales totals
        // ======================================================

        [HttpGet]
        public async Task<IActionResult> Dashboard()
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (!User.IsInRole("Seller") && !user.IsSeller)
            {
                return Forbid();
            }


            // =================================================
            // MY PRODUCTS
            // =================================================

            var products = await _context.Products
                .Where(p => p.SellerId == user.Id && !p.IsRemoved)
                .OrderByDescending(p => p.Id)
                .ToListAsync();

            var productCount = products.Count;


            // =================================================
            // MY ORDERS
            // (orders containing at least one of my products)
            // =================================================

            var orders = await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .Where(o =>
                    o.OrderItems.Any(oi =>
                        oi.Product != null &&
                        oi.Product.SellerId == user.Id))
                .OrderByDescending(o => o.OrderDate)
                .ToListAsync();

            var orderCount = orders.Count;

            var pendingOrderCount = orders
                .Count(o => o.Status == OrderStatus.Pending);


            // =================================================
            // TOTAL SALES
            // (sum of this seller's order-item subtotals,
            // excluding cancelled orders)
            // =================================================

            decimal totalSales = orders
                .Where(o => o.Status != OrderStatus.Cancelled)
                .SelectMany(o => o.OrderItems)
                .Where(oi =>
                    oi.Product != null &&
                    oi.Product.SellerId == user.Id)
                .Sum(oi => oi.UnitPrice * oi.Quantity);


            ViewBag.ProductCount = productCount;
            ViewBag.OrderCount = orderCount;
            ViewBag.PendingOrderCount = pendingOrderCount;
            ViewBag.TotalSales = totalSales;
            ViewBag.RecentOrders = orders.Take(5).ToList();
            ViewBag.RecentProducts = products.Take(5).ToList();

            return View();
        }
    }
}
