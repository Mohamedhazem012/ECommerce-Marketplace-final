﻿using ECommerceMarketplace.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommerceMarketplace.Controllers
{
    public class WishlistController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public WishlistController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // VIEW WISHLIST
        
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var wishlistItems = await _context.WishlistItems
                .Include(w => w.Product)
                .ThenInclude(p => p!.Category)
                .Where(w => w.UserId == user.Id)
                .ToListAsync();

            return View(wishlistItems);
        }

        // ADD TO WISHLIST
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(int productId)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var product = await _context.Products
                .FirstOrDefaultAsync(p =>
                    p.Id == productId &&
                    !p.IsRemoved);

            if (product == null)
            {
                return NotFound();
            }

            var existingItem = await _context.WishlistItems
                .FirstOrDefaultAsync(w =>
                    w.UserId == user.Id &&
                    w.ProductId == productId);

            if (existingItem != null)
            {
                TempData["Message"] =
                    "Product is already in your wishlist.";

                return RedirectToAction(
                    "Details",
                    "Product",
                    new { id = productId });
            }

            var wishlistItem = new WishlistItem
            {
                UserId = user.Id,
                ProductId = productId
            };

            _context.WishlistItems.Add(wishlistItem);

            await _context.SaveChangesAsync();

            TempData["Message"] =
                "Product added to wishlist.";

            return RedirectToAction(nameof(Index));
        }


        // REMOVE FROM WISHLIST
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Remove(int id)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var wishlistItem = await _context.WishlistItems
                .FirstOrDefaultAsync(w =>
                    w.Id == id &&
                    w.UserId == user.Id);

            if (wishlistItem == null)
            {
                return NotFound();
            }

            _context.WishlistItems.Remove(wishlistItem);

            await _context.SaveChangesAsync();

            TempData["Message"] =
                "Product removed from wishlist.";

            return RedirectToAction(nameof(Index));
        }
    }
}