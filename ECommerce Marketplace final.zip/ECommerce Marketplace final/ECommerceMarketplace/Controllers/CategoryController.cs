﻿using ECommerceMarketplace.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommerceMarketplace.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CategoryController(ApplicationDbContext context)
        {
            _context = context;
        }

        // VIEW ALL CATEGORIES

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var categories = await _context.Categories
                .OrderBy(c => c.Name)
                .ToListAsync();

            return View(categories);
        }

        // CREATE CATEGORY - GET
        [HttpGet]
        public IActionResult Create()
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            return View();
        }

        // CREATE CATEGORY - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Category category)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            if (!ModelState.IsValid)
            {
                return View(category);
            }

            _context.Categories.Add(category);

            await _context.SaveChangesAsync();

            TempData["Message"] =
                "Category added successfully.";

            return RedirectToAction(nameof(Index));
        }

        // EDIT CATEGORY - GET
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var category = await _context.Categories
                .FindAsync(id);

            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        // EDIT CATEGORY - POST

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(
            int id,
            Category category)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            if (id != category.Id)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                return View(category);
            }

            try
            {
                _context.Categories.Update(category);

                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Categories
                    .Any(c => c.Id == category.Id))
                {
                    return NotFound();
                }

                throw;
            }

            TempData["Message"] =
                "Category updated successfully.";

            return RedirectToAction(nameof(Index));
        }

        // DELETE CATEGORY - GET
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var category = await _context.Categories
                .FindAsync(id);

            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        // DELETE CATEGORY - POST
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(
            int id)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var category = await _context.Categories
                .FindAsync(id);

            if (category == null)
            {
                return NotFound();
            }

            _context.Categories.Remove(category);

            await _context.SaveChangesAsync();

            TempData["Message"] =
                "Category deleted successfully.";

            return RedirectToAction(nameof(Index));
        }
    }
}
