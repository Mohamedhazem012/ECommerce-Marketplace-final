﻿using ECommerceMarketplace.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommerceMarketplace.Controllers
{
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public OrderController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // ======================================================
        // CUSTOMER - VIEW MY ORDERS
        // ======================================================

        [HttpGet]
        public async Task<IActionResult> MyOrders()
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var orders = await _context.Orders
                .Where(o => o.UserId == user.Id)
                .OrderByDescending(o => o.OrderDate)
                .ToListAsync();

            return View(orders);
        }


        // ======================================================
        // CUSTOMER - ORDER DETAILS
        // ======================================================

        [HttpGet]
        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var order = await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
            {
                return NotFound();
            }

            // CUSTOMER
            if (User.IsInRole("Customer"))
            {
                if (order.UserId != user.Id)
                {
                    return Forbid();
                }
            }

            // SELLER
            else if (User.IsInRole("Seller"))
            {
                var hasSellerProduct = order.OrderItems
                    .Any(oi =>
                        oi.Product != null &&
                        oi.Product.SellerId == user.Id);

                if (!hasSellerProduct)
                {
                    return Forbid();
                }
            }

            // ADMIN
            else if (User.IsInRole("Admin"))
            {
                // Admin can see all orders
            }
            else
            {
                return Forbid();
            }

            return View(order);
        }
        // ======================================================
        // CUSTOMER - CANCEL ORDER
        // ======================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cancel(int id)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var order = await _context.Orders
                .FirstOrDefaultAsync(o =>
                    o.Id == id &&
                    o.UserId == user.Id);

            if (order == null)
            {
                return NotFound();
            }

            // Customer can cancel only Pending or Confirmed orders
            if (order.Status != OrderStatus.Pending &&
                order.Status != OrderStatus.Confirmed)
            {
                TempData["Error"] =
                    "This order cannot be cancelled.";

                return RedirectToAction(
                    nameof(Details),
                    new { id });
            }

            order.Status = OrderStatus.Cancelled;

            await _context.SaveChangesAsync();

            TempData["Message"] =
                "Order cancelled successfully.";

            return RedirectToAction(
                nameof(Details),
                new { id });
        }


        // ======================================================
        // CHECKOUT - GET
        // ======================================================

        [HttpGet]
        public async Task<IActionResult> Checkout()
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var cartItems = await _context.CartItems
                .Include(c => c.Product)
                .Where(c => c.UserId == user.Id)
                .ToListAsync();

            if (!cartItems.Any())
            {
                TempData["Error"] =
                    "Your cart is empty.";

                return RedirectToAction(
                    "Index",
                    "Cart");
            }

            // Check stock before showing checkout
            foreach (var item in cartItems)
            {
                if (item.Product == null ||
                    item.Product.IsRemoved)
                {
                    TempData["Error"] =
                        "One of the products in your cart is no longer available.";

                    return RedirectToAction(
                        "Index",
                        "Cart");
                }

                if (item.Quantity > item.Product.Quantity)
                {
                    TempData["Error"] =
                        $"Not enough stock for {item.Product.Name}. " +
                        $"Available quantity: {item.Product.Quantity}.";

                    return RedirectToAction(
                        "Index",
                        "Cart");
                }
            }

            decimal total = cartItems.Sum(
                item => item.UnitPrice * item.Quantity);

            ViewBag.Total = total;

            return View(cartItems);
        }


        // ======================================================
        // CHECKOUT - POST
        // ======================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CheckoutPost()
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Get cart
            var cartItems = await _context.CartItems
                .Include(c => c.Product)
                .Where(c => c.UserId == user.Id)
                .ToListAsync();

            if (!cartItems.Any())
            {
                TempData["Error"] =
                    "Your cart is empty.";

                return RedirectToAction(
                    "Index",
                    "Cart");
            }


            // ==================================================
            // FINAL STOCK VALIDATION
            // ==================================================

            foreach (var item in cartItems)
            {
                if (item.Product == null ||
                    item.Product.IsRemoved)
                {
                    TempData["Error"] =
                        "One of the products in your cart is no longer available.";

                    return RedirectToAction(
                        "Index",
                        "Cart");
                }

                if (item.Quantity > item.Product.Quantity)
                {
                    TempData["Error"] =
                        $"Not enough stock for {item.Product.Name}. " +
                        $"Available quantity: {item.Product.Quantity}.";

                    return RedirectToAction(
                        "Index",
                        "Cart");
                }
            }


            // ==================================================
            // CALCULATE TOTAL
            // ==================================================

            decimal total = cartItems.Sum(
                item => item.UnitPrice * item.Quantity);


            // ==================================================
            // CREATE ORDER
            // ==================================================

            var order = new Order
            {
                UserId = user.Id,
                OrderDate = DateTime.Now,
                TotalAmount = total,
                Status = OrderStatus.Pending
            };

            _context.Orders.Add(order);

            await _context.SaveChangesAsync();


            // ==================================================
            // CREATE ORDER ITEMS// ==================================================

            foreach (var cartItem in cartItems)
            {
                if (cartItem.Product == null)
                {
                    continue;
                }

                var orderItem = new OrderItem
                {
                    OrderId = order.Id,
                    ProductId = cartItem.ProductId,
                    Quantity = cartItem.Quantity,
                    UnitPrice = cartItem.UnitPrice
                };

                _context.OrderItems.Add(orderItem);


                // REDUCE PRODUCT STOCK
                cartItem.Product.Quantity -=
                    cartItem.Quantity;
            }


            // ==================================================
            // CLEAR CART
            // ==================================================

            _context.CartItems.RemoveRange(cartItems);


            // ==================================================
            // SAVE EVERYTHING
            // ==================================================

            await _context.SaveChangesAsync();

            TempData["Message"] =
                "Order placed successfully!";

            return RedirectToAction(
                nameof(Confirmation),
                new { id = order.Id });
        }


        // ======================================================
        // ORDER CONFIRMATION
        // ======================================================

        [HttpGet]
        public async Task<IActionResult> Confirmation(int id)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var order = await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o =>
                    o.Id == id &&
                    o.UserId == user.Id);

            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }

        // ======================================================
        // SELLER - VIEW ORDERS
        // ======================================================

        [HttpGet]
        public async Task<IActionResult> SellerOrders()
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (!User.IsInRole("Seller") && !user.IsSeller)
            {
                return Forbid();
            }

            var orders = await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .Where(o =>
                    o.OrderItems.Any(oi =>
                        oi.Product != null &&
                        oi.Product.SellerId == user.Id))
                .OrderByDescending(o => o.OrderDate)
                .ToListAsync();

            return View(orders);
        }


        // ======================================================
        // SELLER - UPDATE ORDER STATUS
        // ======================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStatus(
            int id,
            OrderStatus status)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (!User.IsInRole("Seller") && !user.IsSeller)
            {
                return Forbid();
            }

            var order = await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
            {
                return NotFound();
            }

            bool ownsProduct = order.OrderItems.Any(
                oi => oi.Product != null &&
                      oi.Product.SellerId == user.Id);

            if (!ownsProduct)
            {
                return Forbid();
            }

            order.Status = status;

            await _context.SaveChangesAsync();

            TempData["Message"] =
                "Order status updated successfully.";

            return RedirectToAction(nameof(SellerOrders));
        }


        // ======================================================
        // ADMIN - VIEW ALL ORDERS
        // ======================================================

        [HttpGet]
        public async Task<IActionResult> AdminOrders()
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var orders = await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .OrderByDescending(o => o.OrderDate)
                .ToListAsync();

            return View(orders);
        }


        // ======================================================
        // ADMIN - ORDER DETAILS
        // ======================================================

        [HttpGet]
        public async Task<IActionResult> AdminDetails(int id)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var order = await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }
    }
}