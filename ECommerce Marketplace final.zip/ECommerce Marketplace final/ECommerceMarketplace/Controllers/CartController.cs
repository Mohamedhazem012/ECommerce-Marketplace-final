﻿using ECommerceMarketplace.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommerceMarketplace.Controllers
{
    public class CartController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public CartController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // CART INDEX
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var cartItems = await _context.CartItems
                .Include(c => c.Product)
                .ThenInclude(p => p!.Category)
                .Where(c => c.UserId == user.Id)
                .ToListAsync();

            decimal total = 0;

            foreach (var item in cartItems)
            {
                if (item.Product != null)
                {
                    total += item.UnitPrice * item.Quantity;
                }
            }

            ViewBag.Total = total;

            return View(cartItems);
        }


        // ADD TO CART

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddToCart(
            int productId,
            int quantity = 1)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Quantity must be at least 1
            if (quantity < 1)
            {
                TempData["Error"] =
                    "Quantity must be at least 1.";

                return RedirectToAction(
                    "Details",
                    "Product",
                    new { id = productId });
            }

            // Find product
            var product = await _context.Products
                .FirstOrDefaultAsync(p =>
                    p.Id == productId &&
                    !p.IsRemoved);

            if (product == null)
            {
                return NotFound();
            }

            // Product must be in stock
            if (product.Quantity <= 0)
            {
                TempData["Error"] =
                    "This product is out of stock.";

                return RedirectToAction(
                    "Details",
                    "Product",
                    new { id = productId });
            }

            // Find existing cart item
            var cartItem = await _context.CartItems
                .FirstOrDefaultAsync(c =>
                    c.UserId == user.Id &&
                    c.ProductId == productId);

            
            // PRODUCT ALREADY EXISTS IN CART
            
            if (cartItem != null)
            {
                int newQuantity =
                    cartItem.Quantity + quantity;

                // Prevent exceeding stock
                if (newQuantity > product.Quantity)
                {
                    TempData["Error"] =
                        $"Only {product.Quantity} item(s) are available.";

                    return RedirectToAction(
                        "Details",
                        "Product",
                        new { id = productId });
                }

                cartItem.Quantity = newQuantity;

                // Keep latest product price
                cartItem.UnitPrice = product.Price;
            }
            else
            {
                
                // NEW CART ITEM
                
                if (quantity > product.Quantity)
                {
                    TempData["Error"] =
                        $"Only {product.Quantity} item(s) are available.";

                    return RedirectToAction(
                        "Details",
                        "Product",
                        new { id = productId });
                }

                cartItem = new CartItem
                {
                    UserId = user.Id,
                    ProductId = product.Id,
                    Quantity = quantity,
                    UnitPrice = product.Price
                };

                _context.CartItems.Add(cartItem);
            }

            await _context.SaveChangesAsync();

            TempData["Message"] =
                "Product added to cart successfully.";

            return RedirectToAction(nameof(Index));
        }

        
        // UPDATE QUANTITY
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateQuantity(
            int id,
            int quantity)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var cartItem = await _context.CartItems
                .Include(c => c.Product)
                .FirstOrDefaultAsync(c =>
                    c.Id == id &&
                    c.UserId == user.Id);

            if (cartItem == null)
            {
                return NotFound();
            }

            // Quantity cannot be zero or negative here
            if (quantity < 1)
            {
                TempData["Error"] =
                    "Quantity must be at least 1.";

                return RedirectToAction(nameof(Index));
            }

            if (cartItem.Product == null ||
                cartItem.Product.IsRemoved)
            {
                TempData["Error"] =
                    "This product is no longer available.";

                return RedirectToAction(nameof(Index));
            }

            
            // STOCK CHECK
            if (quantity > cartItem.Product.Quantity)
            {
                TempData["Error"] =
                    $"Only {cartItem.Product.Quantity} item(s) are available.";

                return RedirectToAction(nameof(Index));
            }

            cartItem.Quantity = quantity;

            // Update price
            cartItem.UnitPrice =
                cartItem.Product.Price;

            await _context.SaveChangesAsync();

            TempData["Message"] =
                "Cart quantity updated.";

            return RedirectToAction(nameof(Index));
        }

        
        // REMOVE FROM CART
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveFromCart(int id)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var cartItem = await _context.CartItems
                .FirstOrDefaultAsync(c =>
                    c.Id == id &&
                    c.UserId == user.Id);

            if (cartItem == null)
            {
                return NotFound();
            }

            _context.CartItems.Remove(cartItem);

            await _context.SaveChangesAsync();

            TempData["Message"] =
                "Product removed from cart.";

            return RedirectToAction(nameof(Index));
        }

        // CLEAR CART
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ClearCart()
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var cartItems = await _context.CartItems
                .Where(c => c.UserId == user.Id)
                .ToListAsync();

            if (cartItems.Any())
            {
                _context.CartItems.RemoveRange(cartItems);

                await _context.SaveChangesAsync();
            }

            TempData["Message"] =
                "Cart cleared successfully.";

            return RedirectToAction(nameof(Index));
        }
    }
}