﻿using ECommerceMarketplace.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommerceMarketplace.Controllers
{
    public class AdminController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;

        public AdminController(
            UserManager<ApplicationUser> userManager,
            ApplicationDbContext context)
        {
            _userManager = userManager;
            _context = context;
        }

        // ======================================================
        // ADMIN DASHBOARD
        // ======================================================

        [HttpGet]
        public async Task<IActionResult> Dashboard()
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var customerCount = await _userManager.Users
                .CountAsync(u => !u.IsSeller);

            var sellerCount = await _userManager.Users
                .CountAsync(u => u.IsSeller);

            var productCount = await _context.Products
                .CountAsync(p => !p.IsRemoved);

            var orderCount = await _context.Orders
                .CountAsync();

            var pendingOrderCount = await _context.Orders
                .CountAsync(o => o.Status == OrderStatus.Pending);

            ViewBag.CustomerCount = customerCount;
            ViewBag.SellerCount = sellerCount;
            ViewBag.ProductCount = productCount;
            ViewBag.OrderCount = orderCount;
            ViewBag.PendingOrderCount = pendingOrderCount;

            return View();
        }

        // SELLER REQUESTS

        // GET: /Admin/SellerRequests
        [HttpGet]
        public async Task<IActionResult> SellerRequests()
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var users = await _userManager.Users
                .Where(u => u.SellerRequestPending)
                .ToListAsync();

            return View(users);
        }
        // APPROVE SELLER

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveSeller(string id)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var user = await _userManager.FindByIdAsync(id);

            if (user == null)
            {
                return NotFound();
            }

            user.IsSeller = true;
            user.SellerRequestPending = false;

            await _userManager.UpdateAsync(user);

            if (!await _userManager.IsInRoleAsync(user, "Seller"))
            {
                await _userManager.AddToRoleAsync(user, "Seller");
            }

            TempData["Message"] =
                "Seller request approved successfully.";

            return RedirectToAction("SellerRequests");
        }

        // REJECT SELLER

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RejectSeller(string id)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var user = await _userManager.FindByIdAsync(id);

            if (user == null)
            {
                return NotFound();
            }

            user.IsSeller = false;
            user.SellerRequestPending = false;

            await _userManager.UpdateAsync(user);

            TempData["Message"] =
                "Seller request rejected.";

            return RedirectToAction("SellerRequests");
        }

        // VIEW ALL USERS

        // GET: /Admin/Users
        [HttpGet]
        public async Task<IActionResult> Users()
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var users = await _userManager.Users
                .ToListAsync();

            return View(users);
        }

        // ACTIVATE USER

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ActivateUser(string id)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var user = await _userManager.FindByIdAsync(id);

            if (user == null)
            {
                return NotFound();
            }

            user.IsActive = true;

            await _userManager.UpdateAsync(user);

            TempData["Message"] =
                "User activated successfully.";

            return RedirectToAction("Users");
        }

        // SUSPEND USER

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SuspendUser(string id)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var user = await _userManager.FindByIdAsync(id);

            if (user == null)
            {
                return NotFound();
            }

            user.IsActive = false;

            await _userManager.UpdateAsync(user);

            TempData["Message"] =
                "User suspended successfully.";

            return RedirectToAction("Users");
        }
    }
}
