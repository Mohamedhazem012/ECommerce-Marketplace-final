﻿using ECommerceMarketplace.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommerceMarketplace.Controllers
{
    public class ReviewController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public ReviewController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // ======================================================
        // ADD REVIEW
        // CUSTOMER ONLY - MUST HAVE PURCHASED THE PRODUCT
        // ======================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(
            int productId,
            int rating,
            string comment)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var product = await _context.Products
                .FirstOrDefaultAsync(p => p.Id == productId);

            if (product == null)
            {
                return NotFound();
            }

            // ==================================================
            // VALIDATE RATING
            // ==================================================

            if (rating < 1 || rating > 5)
            {
                TempData["Error"] =
                    "Rating must be between 1 and 5.";

                return RedirectToAction(
                    "Details",
                    "Product",
                    new { id = productId });
            }

            if (string.IsNullOrWhiteSpace(comment))
            {
                TempData["Error"] =
                    "Please write a comment for your review.";

                return RedirectToAction(
                    "Details",
                    "Product",
                    new { id = productId });
            }

            // ==================================================
            // MAKE SURE THE CUSTOMER ACTUALLY PURCHASED
            // THIS PRODUCT (in a Delivered order)
            // ==================================================

            bool hasPurchased = await _context.OrderItems
                .Include(oi => oi.Order)
                .AnyAsync(oi =>
                    oi.ProductId == productId &&
                    oi.Order != null &&
                    oi.Order.UserId == user.Id &&
                    oi.Order.Status == OrderStatus.Delivered);

            if (!hasPurchased)
            {
                TempData["Error"] =
                    "You can only review products you have purchased and received.";

                return RedirectToAction(
                    "Details",
                    "Product",
                    new { id = productId });
            }

            // ==================================================
            // ONE REVIEW PER CUSTOMER PER PRODUCT
            // ==================================================

            var existingReview = await _context.Reviews
                .FirstOrDefaultAsync(r =>
                    r.ProductId == productId &&
                    r.UserId == user.Id);

            if (existingReview != null)
            {
                existingReview.Rating = rating;
                existingReview.Comment = comment.Trim();
                existingReview.CreatedAt = DateTime.Now;

                TempData["Message"] =
                    "Your review has been updated.";
            }
            else
            {
                var review = new Review
                {
                    ProductId = productId,
                    UserId = user.Id,
                    Rating = rating,
                    Comment = comment.Trim(),
                    CreatedAt = DateTime.Now
                };

                _context.Reviews.Add(review);

                TempData["Message"] =
                    "Review submitted successfully.";
            }

            await _context.SaveChangesAsync();

            return RedirectToAction(
                "Details",
                "Product",
                new { id = productId });
        }
    }
}
