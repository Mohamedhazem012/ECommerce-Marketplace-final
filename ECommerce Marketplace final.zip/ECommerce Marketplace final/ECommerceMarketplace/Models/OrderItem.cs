﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerceMarketplace.Models
{
    public class OrderItem
    {
        public int Id { get; set; }

        // =========================
        // Order
        // =========================

        [Required]
        public int OrderId { get; set; }

        public Order? Order { get; set; }


        // =========================
        // Product
        // =========================

        [Required]
        public int ProductId { get; set; }

        public Product? Product { get; set; }


        // =========================
        // Quantity
        // =========================

        [Required]
        [Range(1, int.MaxValue)]
        public int Quantity { get; set; }


        // =========================
        // Price
        // =========================

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal UnitPrice { get; set; }


        // =========================
        // Subtotal
        // =========================

        [NotMapped]
        public decimal Subtotal
        {
            get
            {
                return UnitPrice * Quantity;
            }
        }
    }
}