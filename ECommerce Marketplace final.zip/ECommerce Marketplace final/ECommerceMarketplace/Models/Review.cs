﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerceMarketplace.Models
{
    public class Review
    {
        public int Id { get; set; }

        // =========================
        // Product
        // =========================

        [Required]
        public int ProductId { get; set; }

        public Product? Product { get; set; }


        // =========================
        // Customer (Reviewer)
        // =========================

        [Required]
        public string UserId { get; set; } = string.Empty;

        public ApplicationUser? User { get; set; }


        // =========================
        // Rating (1 - 5)
        // =========================

        [Required]
        [Range(1, 5)]
        public int Rating { get; set; }


        // =========================
        // Comment
        // =========================

        [Required]
        [StringLength(1000)]
        public string Comment { get; set; } = string.Empty;


        // =========================
        // Created Date
        // =========================

        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
