﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerceMarketplace.Models
{
    public class CartItem
    {
        public int Id { get; set; }

        // User

        [Required]
        public string UserId { get; set; } = string.Empty;

        public ApplicationUser? User { get; set; }

        // Product

        [Required]
        public int ProductId { get; set; }

        public Product? Product { get; set; }

        // Quantity

        [Required]
        [Range(1, int.MaxValue)]
        public int Quantity { get; set; }

        // Price at time of adding
        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal UnitPrice { get; set; }
    }
}