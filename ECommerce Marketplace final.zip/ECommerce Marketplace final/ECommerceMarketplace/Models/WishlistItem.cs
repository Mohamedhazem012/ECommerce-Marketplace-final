﻿using System.ComponentModel.DataAnnotations;

namespace ECommerceMarketplace.Models
{
    public class WishlistItem
    {
        public int Id { get; set; }

        // User

        [Required]
        public string UserId { get; set; } = string.Empty;

        public ApplicationUser? User { get; set; }


        // Product
        [Required]
        public int ProductId { get; set; }

        public Product? Product { get; set; }
    }
}