﻿
using Microsoft.AspNetCore.Identity;

namespace ECommerceMarketplace.Models
{
    public class ApplicationUser : IdentityUser
    {
        public bool IsActive { get; set; } = true;

        public bool IsSeller { get; set; } = false;

        public bool SellerRequestPending { get; set; } = false;
    }
}