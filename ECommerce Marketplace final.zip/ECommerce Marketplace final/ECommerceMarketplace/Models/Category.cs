﻿using System.ComponentModel.DataAnnotations;

namespace ECommerceMarketplace.Models
{
    public class Category
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;


        // Products in this category
        public ICollection<Product> Products { get; set; }
            = new List<Product>();
    }
}
