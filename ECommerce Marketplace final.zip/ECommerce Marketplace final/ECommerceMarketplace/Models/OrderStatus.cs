﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerceMarketplace.Models
{
    public enum OrderStatus
    {

            Pending,
            Confirmed,
            Shipped,
            Delivered,
            Cancelled
        
    
    }
}