﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerceMarketplace.Models
{
    public class Product
    {
        public int Id { get; set; }

        // Product Name

        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        // Description
        [Required]
        public string Description { get; set; } = string.Empty;

        // Price

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        // Quantity
        [Required]
        public int Quantity { get; set; }

        // Image

        public string? ImageUrl { get; set; }

        // Category
        [Required]
        public int CategoryId { get; set; }

        public Category? Category { get; set; }

        // Seller

        [Required]
        public string SellerId { get; set; } = string.Empty;

        public ApplicationUser? Seller { get; set; }

        // Product Status
        public bool IsApproved { get; set; } = true;
        public bool IsRemoved { get; set; } = false;
    }
}
