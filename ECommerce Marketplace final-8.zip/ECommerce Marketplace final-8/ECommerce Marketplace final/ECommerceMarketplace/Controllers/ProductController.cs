﻿using ECommerceMarketplace.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace ECommerceMarketplace.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public ProductController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }


        // =====================================================
        // VIEW PRODUCTS
        // CUSTOMER / SELLER / ADMIN
        // =====================================================

        [HttpGet]
        public async Task<IActionResult> Index(
            string? search,
            int? categoryId,
            string? sort)
        {
            var currentUser = await _userManager.GetUserAsync(User);

            if (currentUser == null)
            {
                return RedirectToAction("Login", "Account");
            }

            IQueryable<Product> query = _context.Products
                .Include(p => p.Category)
                .Include(p => p.Seller)
                .Where(p => !p.IsRemoved && p.IsApproved);


            // =================================================
            // SELLER
            // Seller sees only his own products
            // =================================================

            if (User.IsInRole("Seller"))
            {
                query = query.Where(
                    p => p.SellerId == currentUser.Id);
            }


            // =================================================
            // CUSTOMER
            // Customer sees all approved products
            // =================================================

            // No extra filter needed for Customer.


            // =================================================
            // ADMIN
            // Admin sees all approved products
            // =================================================

            // No extra filter needed for Admin.


            // =================================================
            // SEARCH
            // =================================================

            if (!string.IsNullOrWhiteSpace(search))
            {
                search = search.Trim();

                query = query.Where(p =>
                    p.Name.Contains(search) ||
                    (p.Description != null &&
                     p.Description.Contains(search)));
            }


            // =================================================
            // FILTER BY CATEGORY
            // =================================================

            if (categoryId.HasValue &&
                categoryId.Value > 0)
            {
                query = query.Where(
                    p => p.CategoryId == categoryId.Value);
            }


            // =================================================
            // SORT
            // =================================================

            switch (sort)
            {
                case "price_asc":

                    query = query.OrderBy(
                        p => p.Price);

                    break;


                case "price_desc":

                    query = query.OrderByDescending(
                        p => p.Price);

                    break;


                case "name_asc":

                    query = query.OrderBy(
                        p => p.Name);

                    break;


                case "name_desc":

                    query = query.OrderByDescending(
                        p => p.Name);

                    break;


                default:

                    query = query.OrderByDescending(
                        p => p.Id);

                    break;
            }// =================================================
            // GET PRODUCTS
            // =================================================

            var products = await query.ToListAsync();


            // =================================================
            // GET CATEGORIES
            // =================================================

            var categories = await _context.Categories
                .OrderBy(c => c.Name)
                .ToListAsync();


            ViewBag.Categories = categories;
            ViewBag.Search = search;
            ViewBag.SelectedCategory = categoryId;
            ViewBag.Sort = sort;


            return View(products);
        }


        // =====================================================
        // CREATE PRODUCT - GET
        // SELLER ONLY
        // =====================================================

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var currentUser =
                await _userManager.GetUserAsync(User);

            if (currentUser == null)
            {
                return RedirectToAction(
                    "Login",
                    "Account");
            }

            if (!currentUser.IsSeller)
            {
                return Forbid();
            }

            await LoadCategories();

            return View();
        }


        // =====================================================
        // CREATE PRODUCT - POST
        // SELLER ONLY
        // =====================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
            Product product)
        {
            var currentUser =
                await _userManager.GetUserAsync(User);

            if (currentUser == null)
            {
                return Unauthorized();
            }

            if (!currentUser.IsSeller)
            {
                return Forbid();
            }


            // Set seller automatically

            product.SellerId = currentUser.Id;

            product.IsApproved = true;

            product.IsRemoved = false;


            // SellerId is assigned automatically

            ModelState.Remove(
                nameof(Product.SellerId));


            if (!ModelState.IsValid)
            {
                await LoadCategories(
                    product.CategoryId);

                return View(product);
            }


            // =================================================
            // IMPORTANT
            // Check that selected Category exists
            // =================================================

            var categoryExists =
                await _context.Categories
                    .AnyAsync(c =>
                        c.Id == product.CategoryId);

            if (!categoryExists)
            {
                ModelState.AddModelError(
                    nameof(Product.CategoryId),
                    "Please select a valid category.");

                await LoadCategories(
                    product.CategoryId);

                return View(product);
            }


            _context.Products.Add(product);

            await _context.SaveChangesAsync();


            TempData["Message"] =
                "Product added successfully.";


            return RedirectToAction(
                nameof(Index));
        }


        // =====================================================
        // PRODUCT DETAILS
        // CUSTOMER / SELLER / ADMIN
        // =====================================================

        [HttpGet]
        public async Task<IActionResult> Details(
            int id)
        {
            var product = await _context.Products
                .Include(p => p.Category)
                .Include(p => p.Seller)
                .FirstOrDefaultAsync(
                    p => p.Id == id &&
                         !p.IsRemoved &&
                         p.IsApproved);


            if (product == null)
            {
                return NotFound();
            }


            // =================================================
            // REVIEWS + OVERALL RATING
            // =================================================

            var reviews = await _context.Reviews
                .Include(r => r.User)
                .Where(r => r.ProductId == id)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();

            ViewBag.Reviews = reviews;

            ViewBag.AverageRating = reviews.Any()
                ? Math.Round(reviews.Average(r => r.Rating), 1)
                : 0;

            ViewBag.ReviewCount = reviews.Count;


            // =================================================
            // CAN THE CURRENT USER REVIEW THIS PRODUCT?
            // Must be logged in, have purchased (Delivered order)
            // =================================================

            var currentUser = await _userManager.GetUserAsync(User);

            bool canReview = false;
            Review? myReview = null;

            if (currentUser != null)
            {
                canReview = await _context.OrderItems
                    .Include(oi => oi.Order)
                    .AnyAsync(oi =>
                        oi.ProductId == id &&
                        oi.Order != null &&
                        oi.Order.UserId == currentUser.Id &&
                        oi.Order.Status == OrderStatus.Delivered);

                myReview = reviews
                    .FirstOrDefault(r => r.UserId == currentUser.Id);
            }

            ViewBag.CanReview = canReview;
            ViewBag.MyReview = myReview;


            return View(product);
        }


        // =====================================================
        // ADMIN - REMOVE PRODUCT
        // =====================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveProduct(
            int id)
        {
            if (!User.IsInRole("Admin"))
            {
                return Forbid();
            }


            var product =
                await _context.Products
                    .FirstOrDefaultAsync(
                        p => p.Id == id);


            if (product == null)
            {
                return NotFound();
            }


            product.IsRemoved = true;


            await _context.SaveChangesAsync();


            TempData["Message"] =
                "Product removed successfully.";


            return RedirectToAction(
                nameof(Index));
        }


        // =====================================================
        // EDIT PRODUCT - GET
        // SELLER / ADMIN
        // =====================================================

        [HttpGet]
        public async Task<IActionResult> Edit(
            int id)
        {
            var currentUser =
                await _userManager.GetUserAsync(User);

            if (currentUser == null)
            {
                return Unauthorized();
            }


            var product =
                await _context.Products
                    .FirstOrDefaultAsync(
                        p => p.Id == id);


            if (product == null)
            {
                return NotFound();
            }


            // Seller can edit only his own product

            if (!User.IsInRole("Admin") &&
                product.SellerId != currentUser.Id)
            {
                return Forbid();
            }


            await LoadCategories(
                product.CategoryId);


            return View(product);
        }


        // =====================================================
        // EDIT PRODUCT - POST
        // SELLER / ADMIN
        // =====================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(
            int id,
            Product product)
        {
            var currentUser =
                await _userManager.GetUserAsync(User);

            if (currentUser == null)
            {
                return Unauthorized();
            }


            if (id != product.Id)
            {
                return NotFound();
            }


            var existingProduct =
                await _context.Products
                    .FirstOrDefaultAsync(
                        p => p.Id == id);


            if (existingProduct == null)
            {
                return NotFound();
            }


            // Seller can edit only his own product

            if (!User.IsInRole("Admin") &&
                existingProduct.SellerId != currentUser.Id)
            {
                return Forbid();
            }


            // SellerId should not come from the form

            ModelState.Remove(
                nameof(Product.SellerId));


            if (!ModelState.IsValid)
            {
                await LoadCategories(
                    product.CategoryId);

                return View(product);
            }


            // Check category

            var categoryExists =
                await _context.Categories
                    .AnyAsync(c =>
                        c.Id == product.CategoryId);


            if (!categoryExists)
            {
                ModelState.AddModelError(
                    nameof(Product.CategoryId),
                    "Please select a valid category.");

                await LoadCategories(
                    product.CategoryId);

                return View(product);
            }


            existingProduct.Name =product.Name;

            existingProduct.Description =
                product.Description;

            existingProduct.Price =
                product.Price;

            existingProduct.Quantity =
                product.Quantity;

            existingProduct.CategoryId =
                product.CategoryId;

            existingProduct.ImageUrl =
                product.ImageUrl;


            await _context.SaveChangesAsync();


            TempData["Message"] =
                "Product updated successfully.";


            return RedirectToAction(
                nameof(Index));
        }


        // =====================================================
        // DELETE PRODUCT - GET
        // SELLER / ADMIN
        // =====================================================

        [HttpGet]
        public async Task<IActionResult> Delete(
            int id)
        {
            var currentUser =
                await _userManager.GetUserAsync(User);

            if (currentUser == null)
            {
                return Unauthorized();
            }


            var product =
                await _context.Products
                    .Include(p => p.Category)
                    .FirstOrDefaultAsync(
                        p => p.Id == id);


            if (product == null)
            {
                return NotFound();
            }


            if (!User.IsInRole("Admin") &&
                product.SellerId != currentUser.Id)
            {
                return Forbid();
            }


            return View(product);
        }


        // =====================================================
        // DELETE PRODUCT - POST
        // SELLER / ADMIN
        // =====================================================

        [HttpPost]
        [ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(
            int id)
        {
            var currentUser =
                await _userManager.GetUserAsync(User);

            if (currentUser == null)
            {
                return Unauthorized();
            }


            var product =
                await _context.Products
                    .FirstOrDefaultAsync(
                        p => p.Id == id);


            if (product == null)
            {
                return NotFound();
            }


            if (!User.IsInRole("Admin") &&
                product.SellerId != currentUser.Id)
            {
                return Forbid();
            }


            product.IsRemoved= true;


            await _context.SaveChangesAsync();


            TempData["Message"] =
                "Product deleted successfully.";


            return RedirectToAction(
                nameof(Index));
        }


        // =====================================================
        // UPDATE QUANTITY
        // SELLER / ADMIN
        // =====================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateQuantity(
            int id,
            int quantity)
        {
            var currentUser =
                await _userManager.GetUserAsync(User);

            if (currentUser == null)
            {
                return Unauthorized();
            }


            var product =
                await _context.Products
                    .FirstOrDefaultAsync(
                        p => p.Id == id);


            if (product == null)
            {
                return NotFound();
            }


            if (!User.IsInRole("Admin") &&
                product.SellerId != currentUser.Id)
            {
                return Forbid();
            }


            if (quantity < 0)
            {
                TempData["Error"] =
                    "Quantity cannot be negative.";

                return RedirectToAction(
                    nameof(Index));
            }


            product.Quantity =
                quantity; await _context.SaveChangesAsync();


            TempData["Message"] =
                "Quantity updated successfully.";


            return RedirectToAction(
                nameof(Index));
        }


        // =====================================================
        // LOAD CATEGORIES
        // =====================================================

        private async Task LoadCategories(
            int? selectedCategory = null)
        {
            var categories =
                await _context.Categories
                    .OrderBy(c => c.Name)
                    .ToListAsync();


            ViewBag.Categories =
                new SelectList(
                    categories,
                    "Id",
                    "Name",
                    selectedCategory);
        }
    }
}